// import { TestBed } from "@angular/core/testing";
// import { CalculatorService } from "./calculator.service";
// import { LoggerService } from "./logger.service";

// describe("CaculatorService", () => {
//   //before each method
//   let calculator: CalculatorService, loggerSpy: any;

//   beforeEach(() => {
//     console.log("calling beforeEach function");
//     loggerSpy = jasmine.createSpyObj("LoggerService", ["log"]);
//     // calculator = new CalculatorService(loggerSpy);
//     TestBed.configureTestingModule;
//     ({
//       providers: [
//         CalculatorService,
//         {
//           provide: LoggerService,
//           useValue: loggerSpy,
//         },
//       ],
//     });
//     calculator = TestBed.get(CalculatorService);
//   });
//   it("should add two numbers", () => {
//     //2nd method
//     // const logger = jasmine.createSpyObj("LoggerService", ["log"]);
//     //logger.log.and.returnValue();
//     // logger.log.and.returnValue(); this line is no longer imp.

//     //1st method
//     // const logger = new LoggerService();
//     // spyOn(logger, "log");
//     // const calculator = new CalculatorService(logger);
//     console.log("add test");
//     const result = calculator.add(2, 2);
//     expect(result).toBe(4);
//     // expect(loggerSpy.log).toHaveBeenCalledTimes(1);
//   });

//   //use f(focus) or x(unfocus) before test case to run debugging
//   it("should substract two numbers", () => {
//     console.log("substract test");
//     // const calculator = new CalculatorService(new LoggerService());
//     const result = calculator.subtract(2, 2);
//     expect(result).toBe(0, "unexpected error in substract");
//     // expect(loggerSpy.log).toHaveBeenCalledTimes(1);
//   });
// });

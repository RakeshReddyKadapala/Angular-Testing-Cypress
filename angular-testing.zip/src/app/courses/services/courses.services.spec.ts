// import { TestBed } from "@angular/core/testing";
// // import { Test } from "mocha";
// import { CoursesService } from "./courses.service";

// import {
//   HttpClientTestingModule,
//   HttpTestingController,
// } from "@angular/common/http/testing";
// import { COURSES, findLessonsForCourse } from "../../../../server/db-data";
// import { Course } from "../model/course";
// import { error } from "console";
// import { HttpErrorResponse } from "@angular/common/http";

// describe("CoursesService", () => {
//   let CoursesService: CoursesService,
//     httpTestingController: HttpTestingController;

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [HttpClientTestingModule],
//       providers: [CoursesService, HttpClientTestingModule],
//     });
//     CoursesService = TestBed.get(CoursesService);
//     httpTestingController = TestBed.get(httpTestingController);
//     // httpTestingController.verify();
//   });

//   it("should retreive all courses", () => {
//     CoursesService.findAllCourses().subscribe((courses) => {
//       expect(courses).toBeTruthy("no courses returned");
//       expect(courses.length).toBe(12, "incorrect no.of courses");

//       const course = courses.find((course) => course.id == 12);

//       expect(course.titles.description).toBe("angular testing course");
//     });

//     const req = httpTestingController.expectOne("/api/course");
//     expect(req.request.method).toEqual("GET");
//     //The argument that we are going to pass here to these Flesche Cole is going to be the test data returned by our mock request.
//     req.flush({ payload: Object.values(COURSES) });
//   });

//   it("should find a course by id", () => {
//     CoursesService.findCourseById(12).subscribe((course) => {
//       expect(course).toBeTruthy();
//       expect(course.id).toBe(12);
//     });

//     const req = httpTestingController.expectOne("/api/course/12");
//     expect(req.request.method).toEqual("GET");
//     //The argument that we are going to pass here to these Flesche Cole is going to be the test data returned by our mock request.
//     req.flush(COURSES[12]);
//     // httpTestingController.verify();
//   });

//   it("should save the course data", () => {
//     const changes: Partial<Course> = {
//       titles: { description: "Testing Course" },
//     };
//     CoursesService.saveCourse(12, changes).subscribe((course) => {
//       expect(course.id).toBe(12);
//     });
//     const req = httpTestingController.expectOne("api/courses/12");
//     expect(req.request.method).toEqual("PUT");
//     expect(req.request.body.titles.description).toEqual(
//       changes.titles.description
//     );
//     req.flush({ ...COURSES[12], ...changes });
//   });

//   it("should give an error if save course fails", () => {
//     const changes: Partial<Course> = {
//       titles: { description: "Testing Course" },
//     };

//     CoursesService.saveCourse(12, changes).subscribe(
//       () => fail("the savea course operation should failed"),
//       (error: HttpErrorResponse) => {
//         expect(error.status).toBe(500);
//       }
//     );
//     const req = httpTestingController.expectOne("api/courses/12");
//     expect(req.request.method).toEqual("PUT");
//     req.flush("save course failed", {
//       status: 500,
//       statusText: "internal server error",
//     });
//   });

//   it("should find a list of lessons", () => {
//     CoursesService.findLessons(12).subscribe((lessons) => {
//       expect(lessons).toBeTruthy();
//       expect(lessons.length).toBe(3);
//     });
//     const req = httpTestingController.expectOne(
//       (req) => req.url == "/api/lessons"
//     );
//     expect(req.request.method).toEqual("GET");
//     expect(req.request.params.get("courseId")).toEqual("");
//     expect(req.request.params.get("sortOrder")).toEqual("asc");
//     expect(req.request.params.get("pageNumber")).toEqual("0");
//     expect(req.request.params.get("pageSize")).toEqual("3");
//     req.flush({
//       payload: findLessonsForCourse(12).slice(0, 3),
//     });
//   });

//   afterEach(() => {
//     httpTestingController.verify();
//   });
// });

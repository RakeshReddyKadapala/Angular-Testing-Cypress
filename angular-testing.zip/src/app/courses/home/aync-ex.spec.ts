import { fakeAsync, flush, flushMicrotasks, tick } from "@angular/core/testing";
import { delay } from "cypress/types/bluebird";
import { promise } from "protractor";
import { of } from "rxjs";
import { callbackify } from "util";

describe("Async Testing Example", () => {
    it("Asynchronous test example with jasmine done()", (done: DoneFn) => {
        let test = false;
        setTimeout(() => {
            console.log("running assertions");
            test = true;
            expect(test).toBeTruthy();
            done();

        }, 500);
    })


    it("asynchronous test example-setTimeout()", fakeAsync(() => {
        let test = false
        setTimeout(() => {
            console.log("running assertions");
            test = true;
            expect(test).toBeTruthy();


        }, 500);
        tick(1000);
    }));


    it("asynchronous test example-plain promise", fakeAsync(() => {
        let test = false
        console.log('create promise');
        setTimeout(() => {
            console.log('setTimeout() first callback triggered')

        });
        setTimeout(() => {
            console.log('setTimeout() second callback triggered')

        });

        // promise.resolve().then(() => {
        //     console.log("promise first then() evaluated successfully")
        //     return promise.resolve();

        // }).then(() => {
        //     console.log('promise second then() evaluated successfully')
        //     test = true;
        // });
        // flushMicrotasks();
        // console.log("running test assertions")
        // expect(test).toBeTruthy();


    }))

    // it('Asynchronous test example-promises+setTimeout()', fakeAsync(() => {
    //     let counter = 0;
    //     promise.Resolve().then(() => {
    //         counter += 10;
    //         setTimeout(() => {
    //             counter += 1;
    //         }, 1000);

    //     });
    //     expect(counter).toBe(0);
    //     flushMicrotasks();
    //     expect(counter).toBe(10);
    //     tick(500);
    //     expect(counter).toBe(10);
    //     tick(500);
    //     expect(counter).toBe(11)
    // }))


    // it("asynchronous test exmple-observable", fakeAsync(() => {
    //     let test = false;
    //     console.log('creating observable');
    //     const test$ = of(test).pipe(delay(1000));
    //     test$.subscribe(() => {
    //         test = true;
    //     });
    //     tick(1000);
    //     console.log('running test assertions');
    //     expect(test).toBe(true);
    // }))




});

